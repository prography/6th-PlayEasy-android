package com.prography.playeasy.match.domain;

import java.util.Date;

public class Match {

    private int id;
    private String title;
    private String type;
    private String description;
    private String location;
    private int fee;
    private Date startAt;
    private Date endAt;
    private int homeQuota;
    private int writerId;
    private int homeTeamId;
    private int awayQuota;
    private int awayTeamId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public Date getStartAt() {
        return startAt;
    }

    public void setStartAt(Date startAt) {
        this.startAt = startAt;
    }

    public Date getEndAt() {
        return endAt;
    }

    public void setEndAt(Date endAt) {
        this.endAt = endAt;
    }

    public int getHomeQuota() {
        return homeQuota;
    }

    public void setHomeQuota(int homeQuota) {
        this.homeQuota = homeQuota;
    }

    public int getWriterId() {
        return writerId;
    }

    public void setWriterId(int writerId) {
        this.writerId = writerId;
    }

    public int getHomeTeamId() {
        return homeTeamId;
    }

    public void setHomeTeamId(int homeTeamId) {
        this.homeTeamId = homeTeamId;
    }

    public int getAwayQuota() {
        return awayQuota;
    }

    public void setAwayQuota(int awayQuota) {
        this.awayQuota = awayQuota;
    }

    public int getAwayTeamId() {
        return awayTeamId;
    }

    public void setAwayTeamId(int awayTeamId) {
        this.awayTeamId = awayTeamId;
    }

    @Override
    public String toString() {
        return "Match{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", location='" + location + '\'' +
                ", fee=" + fee +
                ", startAt=" + startAt +
                ", endAt=" + endAt +
                ", homeQuota=" + homeQuota +
                ", writerId=" + writerId +
                ", homeTeamId=" + homeTeamId +
                ", awayQuota=" + awayQuota +
                ", awayTeamId=" + awayTeamId +
                '}';
    }
}
