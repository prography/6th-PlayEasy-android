package com.prography.playeasy.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.prography.playeasy.R;

public class MainActivity extends AppCompatActivity {
//매치 화면 정보 받아오는 화면인데 아직 구현 안됨
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
