package com.prography.playeasy.mypage.activity;

        import android.os.Bundle;

        import androidx.appcompat.app.AppCompatActivity;

        import com.prography.playeasy.R;


public class PushActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage_push);
    }

}
